import java.util.*;
public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s1 = "Valli";
		String s2 = new String("Ammu");
		int n = sc.nextInt();
		char c[] = new char[n];
		for(int i = 0; i< n;i++) {
			c[i] = sc.next().charAt(0);
		}
		byte b[] = new byte[n];
		for(int i = 0; i< n;i++) {
			b[i] = sc.nextByte();
		}
		String s4 = new String(b);
		String s3 = new String(c);
		String S3 = new String();
		
		
		S3=sc.next();
		System.out.println(s1 + " " + s2 + " " + S3 + " " + s3 + " " + s4);
		
	}

}
