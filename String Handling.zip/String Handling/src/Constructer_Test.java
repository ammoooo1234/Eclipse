
public class Constructer_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructers constructers = new Constructers(1, "ABC");
		System.out.println(constructers);
	}

}
