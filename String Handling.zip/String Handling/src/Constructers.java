
public class Constructers {

	int id;
	String name;
		// TODO Auto-generated method stub
		
	Constructers(int id, String name){
			this.id= id;
			this.name=name;
			
		}

}
