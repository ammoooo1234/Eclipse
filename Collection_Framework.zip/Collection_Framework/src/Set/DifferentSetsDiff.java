package Set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class DifferentSetsDiff {

	public static void main(String[] args) {
		
		Random object = new Random();
		HashSet<Integer> set = new HashSet<>();
		LinkedHashSet set2 = new LinkedHashSet();
		Set<Integer> set3 = new TreeSet<>();
		
		for(int i = 0; i<10;i++) {
			int number = object.nextInt(1,10);
			set.add(number);
			set2.add(number);
			set3.add(number);
		}
		System.out.println(set);
		System.out.println(set2);
		System.out.println(set3);
		
	}

}
