package list;
import java.util.*;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object objects[] = new Object[100000];
		
		for(int i=0;i < objects.length; i++) {
			objects[i] = new Object();
		}
		LinkedList<Object> list = new LinkedList<Object>();
		long start = System.currentTimeMillis();
		for(Object object : objects) {
			list.add(object);
		}
		long end = System.currentTimeMillis();
		
		System.out.println("Total Time taken :" + (end-start));
	}

}
