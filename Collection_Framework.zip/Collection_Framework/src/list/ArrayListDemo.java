package list;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.*;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(20);
		list.add(29);
		list.add(3.01);
		list.add("Birthday");
		System.out.println(list);
		
		
		System.out.println(list);
		

	}

}
