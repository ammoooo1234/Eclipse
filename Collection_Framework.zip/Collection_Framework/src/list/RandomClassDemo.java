package list;
import java.util.*;

public class RandomClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random object = new Random();
		int x = object.nextInt(90, 100);
		System.out.println(x);

	}

}
