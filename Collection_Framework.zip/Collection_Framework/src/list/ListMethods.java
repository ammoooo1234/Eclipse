package list;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import list.ArrayListDemo;


public class ListMethods{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list = new ArrayList();
		for(int i = 0; i<=100; i++) {
			list.add(i);
		}
		/* System.out.println("Initial list: " + list );
		
		list.add(20,21);
		System.out.println("list after insertion: " + list );
		list.set(100, 200);
		System.out.println("list after replacement: " + list ); */
		
		List Bus = new ArrayList();
		
		Bus.add("111V");
		Bus.add("411V");
		Bus.add("222V");
		Bus.add("211V");
		System.out.println("ELEMENTS IN BUS");
		
		System.out.println(Bus + "\n");
		
		System.out.println("APPLYING METHODS ON ELEMENTS IN BUS");
		
		Bus.addAll(4, Bus);
		
		System.out.println(Bus + "\n");
		if(Bus.contains("222V")){
			System.out.println("True");
		}
		System.out.println("\n");
		System.out.println("ELEMENTS IN BUS:");
		
		for(int i=0; i<Bus.size(); i++) {
			System.out.println(Bus.get(i));
		}
		System.out.println("\n");
		System.out.println("ELEMENTS IN BUS AFTER DELETION:");
		Bus.remove(7);
		System.out.println(Bus + "\n");
		
		System.out.println("ELEMENTS IN FORWARD TRAVERSING:");
		
		ListIterator itr = Bus.listIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
			//itr.remove();
		}
		System.out.println("\n");
		
		System.out.println("ELEMENTS IN BACKWARD TRAVERSING:");
		
		while(itr.hasPrevious()) {
			System.out.println(itr.previous());
			itr.remove();
		}
		System.out.println("\nREMOVING ALL ELEMENTS IN BUS");
		System.out.println(Bus + "\n");
		
	
		
	

	}

}
