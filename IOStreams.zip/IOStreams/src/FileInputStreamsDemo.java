import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.*;


public class FileInputStreamsDemo {

	public static void main(String[] args) {
		try {
			FileInputStream fis = new FileInputStream(new File("E:\\Java\\CTS\\src\\IO\\log"));
			
			BufferedReader br = new BufferedReader(new FileReader(new File("E:\\Java\\CTS\\src\\IO\\log")));
			String st;
				while((st = br.readLine())!= null) {
					System.out.println(st + " ***USING BUFFERREADER***");
					}
			int i;
			String s = "";
				while((i = fis.read())!= -1) {
					System.out.print((char)i);
					s += (char)i;
					}
				System.out.println("\n"+ s + " ***USING FILEINPUTSTREAM***");
				fis.close();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
