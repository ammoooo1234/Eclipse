 
public class Main {
	int num; 
	Main(){
		System.out.println("Inside the cons");
	}
	{
		System.out.println("Inside the static block");
	}
	public static void main(String args[]) {
		System.out.println("Inside the main method");
		new Main();
	}

}
