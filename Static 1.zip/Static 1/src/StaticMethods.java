
public class StaticMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticMethods.method1();
		System.out.println("Inside main method");
	}
	static void method1()
	{
		System.out.println("Inside method1");
	}
	static {
		System.out.println("Inside Static block");
		StaticMethods.method1();
	}

	
}
