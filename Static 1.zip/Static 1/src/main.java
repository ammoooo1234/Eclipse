import java.util.*;
import java.text.*;

public class main {

	  public static void main (String[] args) {
		  DecimalFormat df2 =new DecimalFormat("0.00");
	      Scanner sc= new Scanner (System.in);

	      System.out.println("Enter the no of liters to fill the tank");
	      int l =sc.nextInt();
	      double lt= (l*1.00);
	      System.out.println("Enter the distance in km");
	      int d =sc.nextInt();
	      double ds = (d*1.00);
	      double lk = ((lt/ds)*100);
	      System.out.printf("LITRES/100KM \n");
	      System.out.printf(df2.format(lk));
	      }
	  static {
			 System.out.println("Hello There!!!");
		}

}
