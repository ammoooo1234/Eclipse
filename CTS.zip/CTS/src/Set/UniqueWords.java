package Set;
import java.util.*;  
import java.io.*;


public class UniqueWords {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String article = sc.nextLine().toLowerCase();
		Set<String> set = new TreeSet<>();
		
		String[] words = article.split("[,;:.?!\\s+]");
		//System.out.println(words);
		int count = 0;
		
		for(String string : words) {
			if(!string.isEmpty()) {
				count += 1;
			}
		}
		System.out.println(count);
		
		for(String val : article.split("[  ,;:.?!]")) {
			set.add(val);
		}
		set.remove("");
		System.out.println(set.size());
		
		Iterator itr = set.iterator();
		int i = 1;
		while(itr.hasNext()) {
			System.out.println(i + "." + itr.next());
			i += 1;
			//itr.remove();
		}
		
		
	}
}
