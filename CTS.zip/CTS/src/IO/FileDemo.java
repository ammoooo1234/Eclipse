package IO;
import java.io.*;
import java.util.*;

public class FileDemo {

	public static void main(String[] args) {
		
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("E:\\Java\\CTS\\src\\IO\\log")));
			String st;
				while((st = br.readLine())!= null) {
					System.out.println(st);
			} 
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}catch (IOException e) {
			
			e.printStackTrace();
		}
		

	}

}
