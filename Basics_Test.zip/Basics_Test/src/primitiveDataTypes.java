public class primitiveDataTypes{
		
		byte i = 67;
		short j = 0;
		int k = 0;
		long l = 0;
		float m = 0;
		double n = 0;
		char ch = 0;
		boolean p = true;
		
		public static void main(String[] args) {
			
			primitiveDataTypes obj = new primitiveDataTypes();
			
			System.out.println("i = " + obj.i + ", j = " + obj.j + ", k = " + obj.k + ", l = " + obj.l);
			System.out.println("m = " + obj.m + ", n = " + obj.n);
			System.out.println("ch = " + obj.ch);
			System.out.println("p = " + obj.p);
			
	}

}
