public class NonPrimitiveDataTypes {

	String str = "hello";
	
	public static void main(String[] args) {
		
		String name = "BTech Smart Class!";
		String wish = "Hello, ";
		
		NonPrimitiveDataTypes obj = new NonPrimitiveDataTypes();
		
		System.out.println("str = " + obj.str);
		
		//using addition method
		System.out.println(wish.concat(name));		
	}
}