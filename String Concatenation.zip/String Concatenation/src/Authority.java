import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Authority {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
	System.out.println("Inmate's  name:");
	String s1= sc.nextLine();
	System.out.println("Inmate's father's name:");
	String s2 = sc.nextLine();
	s1=s1.concat(" ").concat(s2);
	Pattern p1 = Pattern.compile("[^a-zA-Z ]");
	Matcher matcher = p1.matcher (s1); 
	boolean isS1= matcher.find();
	if(isS1){

	System.out.println("Invalid name");

	}else {
		System.out.println(s1.toUpperCase());
	}
	}
}
